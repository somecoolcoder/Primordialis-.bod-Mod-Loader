____________ ________  ____________________ _____  ___   _     _____ _____  ___  ______________   _     _____  ___ ______ ___________ 
| ___ \ ___ \_   _|  \/  |  _  | ___ \  _  \_   _|/ _ \ | |   |_   _/  ___| |  \/  |  _  |  _  \ | |   |  _  |/ _ \|  _  \  ___| ___ \
| |_/ / |_/ / | | | .  . | | | | |_/ / | | | | | / /_\ \| |     | | \ `--.  | .  . | | | | | | | | |   | | | / /_\ \ | | | |__ | |_/ /
|  __/|    /  | | | |\/| | | | |    /| | | | | | |  _  || |     | |  `--. \ | |\/| | | | | | | | | |   | | | |  _  | | | |  __||    / 
| |   | |\ \ _| |_| |  | \ \_/ / |\ \| |/ / _| |_| | | || |_____| |_/\__/ / | |  | \ \_/ / |/ /  | |___\ \_/ / | | | |/ /| |___| |\ \ 
\_|   \_| \_|\___/\_|  |_/\___/\_| \_|___/  \___/\_| |_/\_____/\___/\____/  \_|  |_/\___/|___/   \_____/\___/\_| |_/___/ \____/\_| \_|
                                                                                                                                      
                                                                                                                                      
________   __                                                                                                                         
| ___ \ \ / /                                                                                                                         
| |_/ /\ V /                                                                                                                          
| ___ \ \ /                                                                                                                           
| |_/ / | |                                                                                                                           
\____/  \_/                                                                                                                           
                                                                                                                                      
                                                                                                                                      
 _   _ ___  ___  ___  __   __
| \ | ||  \/  | / _ \ \ \ / /
|  \| || .  . |/ /_\ \ \ V / 
| . ` || |\/| ||  _  | /   \ 
| |\  || |  | || | | |/ /^\ \
\_| \_/\_|  |_/\_| |_/\/   \/
                             
                             
This is the README of the Primordialis Mod Loader, made to load .bod mods. Reminder, THIS IS NOT DESIGNED TO LOAD ACTUAL CODE/MODS INTO THE GAME! This is only to modify your .bod files! Please keep this in mind.
Instructions on how to load a .bod mod:
1. Open the Primordalis Mod Loader
2. Select your body files directory if it hasn't detected one.
3. Select the folder of mods holding the .bod files.
4. Click on Load Mod and confirm.
5. Restart your Primordialis game.
6. Congrats! Now you have custom body plans in your game. If you do not like those body plans, you could restore so you wouldn't reinstall the game again.

MADE BY NMAX